@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "SRC=%~dp0"
set "TARGET="
set "FAILED=0"

if not "%~1"=="" (
  set "TARGET=%~1"
) else (
  call :detectTarget
)

if "%TARGET%"=="" (
  echo [ERROR] Target project path was not provided.
  exit /b 1
)

if not exist "%TARGET%\package.json" (
  echo [ERROR] package.json not found in target:
  echo         %TARGET%
  echo.
  echo Usage:
  echo   apply-modified-files-2026-06-06.bat "C:\path\to\vuln-assessor-v9-main"
  exit /b 1
)

if not exist "%TARGET%\server-mock.js" (
  echo [ERROR] server-mock.js not found in target:
  echo         %TARGET%
  exit /b 1
)

set "BACKUP=%TARGET%\backup-before-modified-2026-06-06-%RANDOM%"
mkdir "%BACKUP%" >nul 2>nul

echo.
echo Applying modified files
echo Source : %SRC%
echo Target : %TARGET%
echo Backup : %BACKUP%
echo.

call :copyOne "server-mock.js"
call :copyOne "src\services\scheduler.js"
call :copyOne "src\services\scriptDeployService.js"
call :copyOne "src\views\collection\index.ejs"
call :copyOne "src\views\diagnosis\ai_result.ejs"
call :copyOne "src\engine\adapters\scriptResult.js"
call :copyOne "src\engine\aiAssessment.js"
call :copyOne "src\engine\llm\providers\mockScriptPatterns.js"
call :copyOne "scripts\ai-ready\fsi_win_ai.ps1"
call :copyOne "scripts\fsi_win_ai.ps1"
call :copyOne "scripts\ai-ready\fsi_unix_ai.sh"
call :copyOne "scripts\ai-ready\fsi_unix_ai.conf"

echo.
if "%FAILED%"=="1" (
  echo [ERROR] Some files failed to copy. Check messages above.
  exit /b 1
)

echo [OK] All modified files were applied.
echo [INFO] Restart the Node server after this batch finishes.
exit /b 0

:detectTarget
if exist "%SRC%..\vuln-assessor-v9-main\package.json" (
  set "TARGET=%SRC%..\vuln-assessor-v9-main"
  exit /b 0
)
if exist "%SRC%..\package.json" if exist "%SRC%..\server-mock.js" (
  set "TARGET=%SRC%.."
  exit /b 0
)
if exist "%CD%\package.json" if exist "%CD%\server-mock.js" (
  set "TARGET=%CD%"
  exit /b 0
)
echo Target project folder was not found automatically.
set /p "TARGET=Enter vuln-assessor-v9-main path: "
exit /b 0

:copyOne
set "REL=%~1"
if not exist "%SRC%%REL%" (
  echo [FAIL] Source missing: %REL%
  set "FAILED=1"
  exit /b 0
)

for %%D in ("%TARGET%\%REL%") do (
  if not exist "%%~dpD" mkdir "%%~dpD" >nul 2>nul
)

if exist "%TARGET%\%REL%" (
  for %%B in ("%BACKUP%\%REL%") do (
    if not exist "%%~dpB" mkdir "%%~dpB" >nul 2>nul
  )
  copy /Y "%TARGET%\%REL%" "%BACKUP%\%REL%" >nul
)

copy /Y "%SRC%%REL%" "%TARGET%\%REL%" >nul
if errorlevel 1 (
  echo [FAIL] %REL%
  set "FAILED=1"
) else (
  echo [OK]   %REL%
)
exit /b 0
