# 2026-06-06 테스트 반영 파일

이 폴더는 전체 소스가 아니라 테스트 서버에 덮어쓸 수정 파일만 모은 폴더입니다.
폴더 구조를 프로젝트 루트 기준으로 유지했습니다.

## 반영 방법

테스트 서버의 `vuln-assessor-v9-main` 프로젝트 루트에 아래 파일들을 같은 경로로 덮어쓰십시오.

가장 쉬운 방법은 이 폴더의 배치파일을 실행하는 것입니다.

```bat
apply-modified-files-2026-06-06.bat "C:\path\to\vuln-assessor-v9-main"
```

수정파일 폴더가 `vuln-assessor-v9-main` 폴더와 같은 상위 폴더에 있으면 배치파일만 더블클릭해도 자동으로 대상 프로젝트를 찾습니다.
덮어쓰기 전 기존 파일은 대상 프로젝트 안의 `backup-before-modified-2026-06-06-*` 폴더로 백업됩니다.

## 포함 파일

- `apply-modified-files-2026-06-06.bat`
  - 아래 수정 파일들을 테스트 서버 프로젝트에 자동 덮어쓰기
  - 덮어쓰기 전 기존 파일 백업

- `server-mock.js`
  - SecuMS 진단 / Script 진단 분리 API
  - Script 배포/실행/진단 처리
  - 기존 SecuMS Script XML 경로 검색 보강

- `src/services/scheduler.js`
  - `source=secums`, `source=script`, `source=both` 분리 실행
  - 기존 Script XML 우선 수집
  - 없으면 AI-ready 스크립트 실행 fallback

- `src/services/scriptDeployService.js`
  - Linux SSH, Windows SMB+WinRM 직접 배포/실행/결과 수집
  - 배포만 / 배포+실행 / 배포+실행+진단 단계 분리

- `src/views/collection/index.ejs`
  - SecuMS 진단 탭 / Script 진단 탭 분리
  - Script 업로드 / Script 배포 탭 유지
  - 개별 실행 및 전체 실행 분리

- `src/views/diagnosis/ai_result.ejs`
  - AI 전체 결과 / LLM 상세 결과 구분 표시

- `src/engine/adapters/scriptResult.js`
  - Script XML 파서
  - SRV 항목만 진단 대상으로 정규화
  - `SRV001` 형식을 `SRV-001` 형식으로 통일
  - AI evidence block / CDATA 처리

- `src/engine/aiAssessment.js`
  - AI/LLM 진단 실행
  - LLM 상세 대상 필터에서 SRV ID 정규화

- `src/engine/llm/providers/mockScriptPatterns.js`
  - Script SRV 패턴/제목/카테고리/심각도/권고 매핑

- `scripts/ai-ready/fsi_win_ai.ps1`
  - Windows AI-ready raw evidence 스크립트
  - 누락 SRV 보강
  - AI evidence block 출력

- `scripts/fsi_win_ai.ps1`
  - Windows PS1 백업 경로용 동일본

- `scripts/ai-ready/fsi_unix_ai.sh`
  - Linux/UNIX AI-ready raw evidence 스크립트
  - AI evidence block 출력
  - CDATA 출력
  - 느린 점검 Fast/Full 제어

- `scripts/ai-ready/fsi_unix_ai.conf`
  - Linux/UNIX 스크립트 수집 범위 설정 파일

## 테스트 후 확인할 것

- 수집 관리 화면에 `SecuMS 진단`과 `Script 진단` 탭이 분리되어 보이는지
- SecuMS 진단 실행 시 SecuMS raw DB만 진단되는지
- Script 진단 실행 시 Script XML만 진단되는지
- Script 배포 화면에서 1. 배포만 / 2. 배포+실행 / 3. 배포+실행+진단이 각각 동작하는지
- 진단 결과 화면에서 AI 전체 결과와 LLM 상세 결과가 구분되는지
- Script XML 진단 결과의 `chk_id`가 모두 `SRV-001` 형식인지
